# SPA_PhotoTagging
PhotoTagging of the SPA 2014 Referendum leaflets 

This application has four files:

* template.html: the view for every task and deal with the data of the answers.
* tutorial.html: a simple tutorial for the volunteers.
* project.json: the setup metadata (make sure name and short name are unique, or create will fail.)
* long_description.md: the long description for the app.
